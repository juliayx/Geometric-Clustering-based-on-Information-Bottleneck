function [ error ] = Find_error( Label ,N_1,N_2)
% Given a 1*(N1+N2) vector, 
% for 1:N1, we find the maximum frequency element
% then calculate the error
% Similarly for N1+1:N2.
A_1 = mode(Label(1:N_1));
B_1 = sum(Label(1:N_1) == A_1);
A_2 = mode(Label(N_1+1:N_1+N_2));
B_2 = sum(Label(N_1+1:N_1+N_2) == A_2);
error = 1 - (B_1 + B_2)/(N_1 + N_2);


end

