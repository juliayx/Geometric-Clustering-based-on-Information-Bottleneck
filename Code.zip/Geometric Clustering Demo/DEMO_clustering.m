function [ label,error,time ] = DEMO_clustering( method, X,K,varargin)
%   Input:
%  method: 'IB' or 'DIB' or 'kmeans'
%       X: data points
%       K: number of clusters
%   label: label of data points
%   error: error of this method
%    time: running time of this method
[l, N] = size(X);  
% l: data dimension; 
% N: number of points


switch(method)
    case 'IB'
        t1=clock;
        beta = 10;
        maxiter = 200; 
        tol = 0.00000001;
        K =2;
        [ label ] = IB( X,beta,maxiter,tol,K);
        [ error ] = Find_error( label ,varargin{:});
        t2=clock;
        time = etime(t2,t1);
        % plot IB clustering
        % marker_color = rand(K,3);
        %  figure
        %  for i = 1:K
        %      [index] = find(label == i);
        %      hold on
        %      plot(X(1,index),X(2,index),'.','MarkerSize',10','Color',marker_color(i,:))
        %  end
    case 'DIB'
        t1=clock;
        beta = 10;
        maxiter = 200; 
        tol = 0.00000001;
        K =2;
        [ label ] = DIB( X,beta,maxiter,tol,K);
        [ error ] = Find_error( label ,varargin{:});
        t2=clock;
        time = etime(t2,t1);
        % plot DIB clustering
        % marker_color = rand(K,3);
        %  figure
        %  for i = 1:K
        %      [index] = find(label == i);
        %      hold on
        %      plot(X(1,index),X(2,index),'.','MarkerSize',10','Color',marker_color(i,:))
        %  end
    case 'my_k_means'
        t1=clock;
        theta = zeros(l,K);
        [~, label, ~] = k_means(X,theta);
        [ error ] = Find_error( label ,varargin{:});
        t2=clock;
        time = etime(t2,t1);
%         % plot kmeans clustering
%         figure; axis equal; box on; 
%         hold on;
%         for k = 1 : K
%             plot(X(1,bel==k),X(2,bel==k),'.','MarkerSize',10','Color',marker_color(k,:))
%         end
%         hold off;
end






end

