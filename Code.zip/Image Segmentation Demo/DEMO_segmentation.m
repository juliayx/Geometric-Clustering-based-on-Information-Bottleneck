clear
format compact
close all

l = 3;
Image = imread('piasf.jpg');
length = 100;
Num_c = 2;
beta = 10;
t1 = clock;
[ Label] = graph_clustering( 'DIB',Image, Num_c,beta,length);
t2 = clock;
time = etime(t2,t1);
%[ Label] = graph_clustering( 'DIB',Image, Num_c,beta,length);