function [ Label ] = graph_clustering( method,Image, Num_c,beta,length)
% Given a graph, this code separate it into different clusters
% Usage:
%   Input:
%  method: 'DIB' or 'IB'
%   Image: a double matrix (gray)
%   Num_c: number of clusters
%    beta: parameter in IB
%  length: length of the image
%  Output:
%   Label: a label matrix, entry \in {1,2,...,Num_c}

Image = im2double(Image);
Image = imresize(Image, [length NaN]);
[m,n,l]=size(Image);
[ii, jj] = find(Image);
kk_1 = 5 * reshape(Image(:,:,1),1,[]);
kk_2 = 5 * reshape(Image(:,:,2),1,[]);
kk_3 = 5 * reshape(Image(:,:,3),1,[]);
%X = zeros(3,m*n);
X = [kk_1;kk_2;kk_3];

[l,N]=size(X);

%figure
%scatter3(X(1,:),X(2,:),X(3,:),'r');
%view(40,35);

%% Initialize
pI = 1/N*ones(N,1);
unnorm_p_X_I = exp((-1/(2)) * distance_matrix(X));
Z_X_I = repmat(sum(unnorm_p_X_I), [N 1]);
p_X_I = unnorm_p_X_I ./ Z_X_I;
pIX = p_X_I' .* repmat(pI, [1 N]);
XC0 = repmat(mean(X,2), [1 Num_c]) + rand(l,Num_c);

my_distance = zeros(N,Num_c);
for i = 1:N
    for j = 1:Num_c
        my_distance(i,j) = mydistance(X(:,i),XC0(:,j));
    end
end


unnorm_p0_X_C = exp(-1*my_distance);
Z0_C_beta = repmat(sum(unnorm_p0_X_C), [N 1]);
p0X_C = unnorm_p0_X_C ./ Z0_C_beta;
p0C = ones(Num_c,1)*(1/Num_c);


%% Implement information bottleneck to clustering

maxiter = 2000;
tol = 0.00000001;
switch(method)
    case 'IB'
        [ pC_I, pX_C, PC, XC ] = Geo_IB_all_iteration( pIX, beta, p0X_C,p0C,X,maxiter, tol );
    case 'DIB'
        [ pC_I, pX_C, PC, XC ] = Geo_DIB_all_iteration( pIX, beta, p0X_C,p0C,X,maxiter, tol );
end

%% Verify its significance
 
Label = zeros(N,1);
 for i = 1:N
     Label(i) = find(pC_I(:,i) == max(pC_I(:,i)));
 end


 Label = reshape(Label, [m,n]);
 
 %% plot the graph
[m,n] = size(Label);
New = zeros(m,n,l);
color_set = rand(Num_c,3);
for i = 1:Num_c
    [index_1,index_2] = find(Label == i);
    for j = 1:max(size(index_1))
        New(index_1(j),index_2(j),:) = color_set(i,:);
    end
end
imshow(New)








end

