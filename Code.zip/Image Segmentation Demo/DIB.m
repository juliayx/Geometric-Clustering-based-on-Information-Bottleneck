function [ label ] = DIB( X,beta,maxiter,tol,K)
%     Input: 
%         X: data points, each column is one datum
%      beta: parameter
%   maxiter: maximum iteration
%       tol: tolerance
%         K: number of clusters
%    Output:
%     label: label of data points
[l,N]=size(X);
pI = 1/N*ones(N,1);
unnorm_p_X_I = exp((-1/(2)) * distance_matrix(X));
Z_X_I = repmat(sum(unnorm_p_X_I), [N 1]);
p_X_I = unnorm_p_X_I ./ Z_X_I;
pIX = p_X_I' .* repmat(pI, [1 N]);
XC0 = repmat(mean(X,2), [1 K]) + rand(2,K);

my_distance = zeros(N,K);
for i = 1:N
    for j = 1:K
        my_distance(i,j) = mydistance(X(:,i),XC0(:,j));
    end
end

unnorm_p0_X_C = exp(-1*my_distance);
Z0_C_beta = repmat(sum(unnorm_p0_X_C), [N 1]);
p0X_C = unnorm_p0_X_C ./ Z0_C_beta;
p0C = ones(K,1)*(1/K);

[ pC_I, pX_C, PC, XC ] = Geo_DIB_all_iteration( pIX, beta, p0X_C,p0C,X,maxiter, tol );

%% Verify its significance
 
 label = zeros(N,1);
 for i = 1:N
     label(i) = find(pC_I(:,i) == max(pC_I(:,i)));
 end
 


end

 